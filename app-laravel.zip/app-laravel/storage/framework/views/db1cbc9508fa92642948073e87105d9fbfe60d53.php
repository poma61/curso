<!--*****************utlizando herencias de plantilla de blade******************-->






<!--*****************utlizando herencias de plantilla de blade******************-->


<!-- *********utlizando componenetes de blade  primera forma***********-->


<!-- *********utlizando componenetes de blade  segunda forma************-->
<!--  x- => hace referencia a la carpeta components y busca la vista layout-->
<!-- la carpeta debe llamarmese 'components para que funcione' -->


<!-- *********utlizando componentes de blade tercera forma************-->
<!-- para referenciar una propiedad o variable utilizamos kebab case -->
<!-- en el archivo layout la misma propiedad o variable utilizamos camelCase -->
<!-- :sum="2+2" ->':' para evaluar como codigo php a  la variable o propiedad -->
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.layouts.app','data' => ['title' => 'Home','metaDescription' => 'Home description','sum' => 2+2]] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Home','meta-description' => 'Home description','sum' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(2+2)]); ?>
    <h1>Inicio</h1>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>


<!-- me quede en el video 10 de curso de larabel --><?php /**PATH C:\laragon\www\app-laravel\resources\views/home.blade.php ENDPATH**/ ?>