 <!-- blade permite escribir codigo php es decir -->
 <!--  es igual a <?php //codigo php; ?>-->
 <!--  es mas seguro protege codigo php pero NO permite ingresar codigo html ?>-->
 <!--{--!! //codigo php;--!!--} permite ingresar codigo html pero no es seguro ?>-->
 <ul>
     <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
     <li><a href="<?php echo e(route('blog')); ?>">Blog</a></li>
     <li><a href="<?php echo e(route('about')); ?>">About</a></li>
     <li><a href="<?php echo e(route('contact')); ?>">Contact</a></li>

 </ul><?php /**PATH C:\laragon\www\app-laravel\resources\views/partials/navigation.blade.php ENDPATH**/ ?>