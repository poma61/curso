<?php $__env->startSection('title','Blog'); ?>

<?php $__env->startSection('meta-description','Blog description'); ?>

<?php $__env->startSection('content'); ?>
<h1>BLOG</h1>













<?php if(session("estado")): ?>
<div style="margin-bottom:10px; color:green; background:rgba(253, 193, 47,0.5); padding:10px;width:200px;text-align:center">
    <?php echo e(session('estado')); ?>

</div>
<?php endif; ?>
<br>
<a href="<?php echo e(route('m.form')); ?>" style="background:#3f51b5;color:#ffffff; padding:10px;">crear nuevo archivo</a>

<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div style="display:flex; align-items:baseline;">
    <h2>
        <a href="<?php echo e(route('m.show',$row)); ?>"><?php echo e($row->title); ?></a>
    </h2>
    <!-- para dar espacio -->
    &nbsp;
    <a href="<?php echo e(route('editar',$row)); ?>">Editar Registro</a>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\app-laravel\resources\views/blog.blade.php ENDPATH**/ ?>