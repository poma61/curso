 <!-- blade permite escribir codigo php es decir -->
 <!-- {{-- //codigo php;--}} es igual a <?php //codigo php; ?>-->
 <!-- {{-- //codigo php;--}} es mas seguro protege codigo php pero NO permite ingresar codigo html ?>-->
 <!--{--!! //codigo php;--!!--} permite ingresar codigo html pero no es seguro ?>-->
 <ul>
     <li><a href="{{ route('home') }}">Home</a></li>
     <li><a href="{{ route('blog') }}">Blog</a></li>
     <li><a href="{{ route('about') }}">About</a></li>
     <li><a href="{{ route('contact')  }}">Contact</a></li>

 </ul>