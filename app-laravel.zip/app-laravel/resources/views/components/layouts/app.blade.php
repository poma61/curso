 {{-- utilizando componentes de blade --}}

 <!DOCTYPE html>
 <html lang="es">

 <head>
     <meta charset="UTF-8">
     <meta http-equiv="X-UA-Compatible" content="IE=edge">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>{{$title ?? ''}}</title>
     <!-- $title ?? '' -> si la variable $title  existe?? coloca el valor , y si no existe coloca vacio -> '' -->
     <!--lasd variables deben definirse en formnato camelCase cuando se utiliza componenetes de blade  -->
     <meta name="decription" content="{{$metaDescription ?? 'default'}}">
 </head>

 <body>
   <!-- para mostrar el menu -->
     <x-layouts.navigation />
     {{-- donde se imprimira el componenete principal--}}
     {{$slot}}
     {{$sum??''}}

 </body>

 </html>