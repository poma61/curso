@extends('layouts.app')

{{-- para cambiar el nombre del titulo de la pagina --}}
@section('title','Contacto')

@section('meta-description','Contacto description')

@section('content')
    <h1>CONTACTO</h1>

    
@endsection
