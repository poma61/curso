  @extends('layouts.app')

  {{-- para cambiar el nombre del titulo de la pagina --}}
@section('title','About')

@section('meta-description','About description')

  @section('content')
  <h1>ABOUT</h1>
  @endsection