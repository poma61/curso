<!--*****************utlizando herencias de plantilla de blade******************-->
{{--@extends('layouts.app')--}}
{{-- para cambiar el nombre del titulo de la pagina --}}
{{--@section('title','Home')--}

{{--
@section('meta-description','Home description')
@section('content')
<h1>Inicio</h1>
@endsection
 --}}



<!--*****************utlizando herencias de plantilla de blade******************-->


<!-- *********utlizando componenetes de blade  primera forma***********-->
{{--
@component('components.layout')
<h1>Inicio</h1>
@endcomponent
--}}

<!-- *********utlizando componenetes de blade  segunda forma************-->
<!--  x- => hace referencia a la carpeta components y busca la vista layout-->
<!-- la carpeta debe llamarmese 'components para que funcione' -->
{{-- 
  <x-layouts.app>
  <x-slot name="title">
    Home title
  </x-slot>
    <h1>Inicio</h1>
</x-layouts.app> 
--}}

<!-- *********utlizando componentes de blade tercera forma************-->
<!-- para referenciar una propiedad o variable utilizamos kebab case -->
<!-- en el archivo layout la misma propiedad o variable utilizamos camelCase -->
<!-- :sum="2+2" ->':' para evaluar como codigo php a  la variable o propiedad -->
<x-layouts.app title="Home" meta-description="Home description" :sum="2+2">
    <h1>Inicio</h1>
</x-layouts.app>


<!-- me quede en el video 10 de curso de larabel -->