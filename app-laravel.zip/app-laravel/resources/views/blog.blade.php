@extends('layouts.app')

{{-- para cambiar el nombre del titulo de la pagina --}}
@section('title','Blog')

@section('meta-description','Blog description')

@section('content')
<h1>BLOG</h1>

{{--primera para mostrar datos de un array--}}
{{--@dump($data) --}}

{{--segunda para mostrar datos de un array--}}
{{--@foreach ($data as $row )--}}
{{-- {{$row['title']}} --}}
{{--@endforeach--}}

{{--tercera forma para mostrar datos de un array--}}
{{--@foreach ($data as $row)--}}
{{--<h1>{{$row->title}} </h1>--}}
{{--@endforeach--}}
@if(session("estado"))
<div style="margin-bottom:10px; color:green; background:rgba(253, 193, 47,0.5); padding:10px;width:200px;text-align:center">
    {{session('estado')}}
</div>
@endif
<br>
<a href="{{route('m.form')}}" style="background:#3f51b5;color:#ffffff; padding:10px;">crear nuevo archivo</a>

@foreach ($data as $row)
<div style="display:flex; align-items:baseline;">
    <h2>
        <a href="{{route('m.show',$row)}}">{{$row->title}}</a>
    </h2>
    <!-- para dar espacio -->
    &nbsp;
    <a href="{{route('editar',$row)}}">Editar Registro</a>
</div>
@endforeach




@endsection