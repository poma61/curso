<x-layouts.app>
<h1>id={{$data->id}} </h1>
<h1>Titulo={{$data->title}} </h1>
</x-layouts.app>
