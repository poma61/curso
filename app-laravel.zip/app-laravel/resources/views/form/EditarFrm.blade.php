<x-layouts.app
title="editar"
meta-description="formulario editar"
>
<h1>Editar registro</h1>
<form action="{{route('f.update',$data->id)}}"  method="POST">
    @csrf 
    <!-- LOS NAVEGADORES SOLO SOPORTAN METODOS GET Y POST -->
    <!--ENTODOS PARA SIMULAR EL METODO PATCH SE DEBE COLOCAR METHOD='POST' -->
    <!--EN EL FORMULARIO, PERO SE DEBE COLOCAR UNA DIRECTIVA BLADE Y COLOCAR -->
    <!--EL METODO 'PATCH' -->
    @method('PATCH')
        <label for="">
            Titulo
            <br>
            <input type="text" name="title" value="{{old('title',$data->title)}}">

            <br>
            @error('title')
               <small style='color:red;'>{{$message}}</small> 
            @enderror
        </label>
        <br>
        <br>
        <button type="submit">Enviar</button>
    </form>
</x-layouts.app>