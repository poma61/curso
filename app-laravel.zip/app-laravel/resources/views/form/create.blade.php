<x-layouts.app>
    <h1>BLOG</h1>
    <form action="{{route('m.enviar')}}"  method="post">
    <!-- siempre se debe agregar cuando sew utiliza un formulario -->
    <!-- con el metodo post -->
    @csrf
    <!-- el token csrf expira dentro de 2 horas -->
        <label for="">
            Titulo
            <br>
            {{--old('title') muestra el valor anterior del input --}}
            {{--se usa cuando pasa un error y no queremos perder los valores --}}
            {{--anteriores llenados en el formulario --}}
            <input type="text" name="title" value="{{old('title')}}">
            <br>
            @error('title')
               <small style='color:red;'>{{$message}}</small> 
            @enderror
        </label>
        <br>
        <br>
        <button type="submit">Enviar</button>
    </form>
</x-layouts.app>