<?php

namespace App\Http\Controllers;

use App\Models\Postmodelo;

class PostController2 extends Controller
{

    public function index(){
        $datos=PostModelo::get();

    return view('blog',['data'=>$datos]);
    }

    public function show (PostModelo $val){
  
        return view('form/show',['data'=>$val]);
    }

    public function create(){
     return view('form/create');
    }

    //enviar datos a la base de datos 
    public function store(){
     
        request()->validate([
            'title'=>['required','min:4']
        ]);

      //devuelve los datos del formulario en formato json
      //  return request();
     $enviar= new PostModelo();
     $enviar->title=request()->input('title');
     $enviar->save();
     session()->flash('estado','Registro Creado');
     return redirect()->route('blog');
    }

    public function editarRegistro(PostModelo $valores){

         return view('form/EditarFrm',['data'=>$valores]);
    }

    public function update(PostModelo $id){
        request()->validate([
            'title'=>['required','min:4']
        ]);
    $id->title=request()->input('title');
    $id->save();
    session()->flash('estado','Registro Modificado');
    return to_route('blog');

    }
}//class

//me quede el el video 22 de cursos de laravel9