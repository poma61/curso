<?php

namespace App\Http\Controllers;


class PostController 
{

    //Esta clase  controlador es util cuando la clase
    //solo tiene un metodo invoke
    public function __invoke(){
         $datos=[
        ['title'=>'first dato'],
        ['title'=>'Second dato'],
        ['title'=>'Third dato'],
        ['title'=>'Fourth dato'],
    ];
    return view('blog',['data'=>$datos]);
    }
}