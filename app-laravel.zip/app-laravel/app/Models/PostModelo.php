<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PostModelo extends Model
{
    use HasFactory;
    //nombre de la tabla de la base de datos 
    protected $table='prueba';

    //Para no colocar protected $table='post'
    // el nombre de la clase debe ser el mismo nombre de la tabla de la base de datos
    //pero el nombre de la clase debe ser en singular y utilizar CamelCase
    //el nombre de la tabla de la base de datos debe ser en plural
    //ejemplo 'class Post'  nombre de la tabla => 'posts'
}
