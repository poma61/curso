<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PostController;
use App\Http\Controllers\PostController2;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//una forma de crear rutas
// Route::get('/', function () {
//     return view('welcome');
// });
$datos=[
    ['title'=>'first dato'],
    ['title'=>'Second dato'],
    ['title'=>'Third dato'],
    ['title'=>'Fourth dato'],
];

Route::view('/','home' )->name('home');
Route::view('/conta','contacto' )->name('contact');
Route::view('/abou','about' )->name('about');
//**********enviar parametros o valores
//1era forma
// Route::view('/blo','blog',['data'=>$datos] )->name('blog');

//2da forma
// Route::get('/blo',function(){
//     $datos=[
//         ['title'=>'first dato'],
//         ['title'=>'Second dato'],
//         ['title'=>'Third dato'],
//         ['title'=>'Fourth dato'],
//     ];
//     return view('blog',['data'=>$datos]);
// } )->name('blog');

//tercer forma
// Route::get('/blo',PostController::class)->name('blog');

//cuarta forma
Route::get('/blo',[PostController2::class,'index'])->name('blog');
Route::post('/blog/enviar',[PostController2::class,'store'])->name('m.enviar');
//patch -> para actualizar un registro
//put ->reemplazar un registro
Route::patch('/update/{id}',[Postcontroller2::class,'update'])->name('f.update');
Route::get('/blog/create',[PostController2::class,'create'])->name('m.form');
Route::get('/blog/{val}',[PostController2::class,'show'])->name('m.show');;
Route::get('/blog/edit/{valores}',[PostController2::class,'editarRegistro'])->name('editar');
//el orden de las rutas es muy importante
// por lo tanto es recomendable colocas las rutas que reciben parametros al final