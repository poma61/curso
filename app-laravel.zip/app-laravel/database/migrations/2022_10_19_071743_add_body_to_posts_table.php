<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    //esta funcion ejecuta el comando por consola
    //php artisan migrate
    public function up()
    {
        Schema::table('posts', function (Blueprint $table) {
            $table->longText('body')->after('contenido');
            //
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    //esta funcion ejecuta el comando por consola
    //php artisan migrate:rollback
    public function down()
    {
        Schema::table('posts', function (Blueprint $table) {
            $table->dropColumn('body');
        });
    }
};
